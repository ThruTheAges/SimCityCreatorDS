# SimCity Creator (DS) Research Repository

feel free to reach out to one of us if you want to be a collaborator or want us to contribute to this repo.

# RULES:
# 1.) No Pornographic or explicit material.
# 2.) File names must be in strict english. No Kanjii nor anything else or I'll delete them. (yes it's okay if they contain a translation.)
# 3.) Please Use the REMS as to specify the purpose of your files.
# 4.) Keep everything neat and organized.
