raw game files extracted using Tinke. most files are unreadable except through Tinke. Important files are only .bin or .txt
